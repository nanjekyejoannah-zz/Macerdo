class SqlGenerator
  
  def GenerateInsert
 
    file = File.open("output.stream.txt")
    contents = ""
 
    file.each {|line|
 
        tokens = line.split(", ")
        date = tokens[0]
        time = tokens[1]
        precision1 = tokens[2]
         precision2 = tokens[3]
          precision3 = tokens[4]
           precision4 = tokens[5]
           precisionscores = tokens[6]
 
        
 
        insertStatement =  "INSERT INTO [outputstream]([Precision1], [Precision4], [Precisionscores],[Date], [Time] ) VALUES ('#{precision1}', '#{precision4}', '#{precisionscores}' '#{date}', '#{time}' );\n"
        contents << insertStatement
        my_file = File.new("output.stream.sql", "w")
        my_file.puts contents
    }
 
  end
   
end
 
 
if __FILE__ == $0
  sql = SqlGenerator.new
  sql.GenerateInsert
end