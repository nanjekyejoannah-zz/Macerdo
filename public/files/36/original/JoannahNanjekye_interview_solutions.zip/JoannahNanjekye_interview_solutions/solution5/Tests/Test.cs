using NUnit.Framework;
using System;

namespace Tests
{
	[TestFixture()]
	public class Test
	{
		[Test()]
		public void test_replace ()
		{
			string testFile = @"/home/joannah/Interview@trialAnalytics/solution5/Tests/output.stream.csv";
			string outputfile = @"/home/joannah/Interview@trialAnalytics/solution5/solution5/output.stream.csv";
			FileAssert.AreEqual (testFile,outputfile);


		}
	}
}

