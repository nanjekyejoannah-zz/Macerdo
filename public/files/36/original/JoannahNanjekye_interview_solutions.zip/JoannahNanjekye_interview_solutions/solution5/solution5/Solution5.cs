using System;
using System.IO;

namespace solution5
{
	class Solution5
	{
		string file = @"/home/joannah/Interview@trialAnalytics/solution5/solution5/output.stream.txt";
		string path = @"/home/joannah/Interview@trialAnalytics/solution5/solution5/output.stream.csv";


		public void replace(string old, string _new){
			string text = File.ReadAllText(file);
			text = text.Replace(old,_new);

			//creates a file in the path and writes the contents there.
			System.IO.File.WriteAllText(path, text);

		}
		public static void Main (string[] args)
		{
			Solution5 x = new Solution5 ();
			string o = ",";
			string n = "|";
			x.replace (o, n);
			Console.WriteLine ("Hello World!");
		}
	}
}
